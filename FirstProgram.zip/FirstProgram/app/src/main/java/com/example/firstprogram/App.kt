package com.example.firstprogram

import android.app.Application

class App:Application() {
    override fun onCreate() {
        super.onCreate()
    }

}